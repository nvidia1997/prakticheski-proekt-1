export interface ReduxAction {
    type: string,
    payload: object
}